# Linea
GTK theme for Cinnamon desktop

## Requirments

### GTK+ 3.20 or later

### GTK2 engines requirment
- GTK2 Murrine engine.
